from .base import BaseField

class BinaryField(BaseField):
    pass
