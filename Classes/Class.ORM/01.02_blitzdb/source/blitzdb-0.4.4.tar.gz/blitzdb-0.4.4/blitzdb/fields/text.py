from .base import BaseField

class TextField(BaseField):
    pass
