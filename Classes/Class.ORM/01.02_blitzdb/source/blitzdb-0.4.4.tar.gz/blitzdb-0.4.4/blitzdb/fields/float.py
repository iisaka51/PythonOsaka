from .base import BaseField

class FloatField(BaseField):
    pass
