from .base import BaseField

class BooleanField(BaseField):
    pass
