from .base import BaseField

class IntegerField(BaseField):
    pass
