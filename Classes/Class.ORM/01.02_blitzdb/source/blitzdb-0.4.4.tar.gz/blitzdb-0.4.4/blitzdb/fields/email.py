from .base import BaseField

class EmailField(BaseField):
    pass
